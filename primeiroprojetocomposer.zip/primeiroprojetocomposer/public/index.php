<?php
    include __DIR__.'/../bootstrap.php';